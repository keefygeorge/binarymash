Dependencies:
nmp install nodejs
nmp install mongojs
nmp install mongojs

To run the server from the .vbs file edit the pathname to point
to your node.exe root directory for example:

"cmd /k cd /d 'PATH TO node.exe - Remove quotes' && node nodeJS-monoDB-monojs-app\server.js"
to 
"cmd /k cd /d d:\nodejs && node nodeJS-monoDB-monojs-app\server.js"

server.js is the execution file for node.js 
